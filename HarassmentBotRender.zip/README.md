# Harassment Telegram Bot

Этот бот продаёт футболки, дюраги и гольфы с оформлением под бренд Harassment. Развёртывается на Render.

## Установка

1. Клонируй репозиторий.
2. Создай `.env` файл и вставь токен бота:
```
BOT_TOKEN=твой_токен_бота
```
3. Установи зависимости:
```
pip install -r requirements.txt
```
4. Запусти:
```
python main.py
```

## Для деплоя на Render
- Build command: `pip install -r requirements.txt`
- Start command: `python main.py`
